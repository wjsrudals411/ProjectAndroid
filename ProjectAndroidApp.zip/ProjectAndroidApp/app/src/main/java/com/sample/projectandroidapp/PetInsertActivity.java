package com.sample.projectandroidapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class PetInsertActivity extends AppCompatActivity {

    private EditText et_name, et_age, et_type;
    private RadioGroup radioGroup;
    private RadioButton radioMale, radioFemale;
    private Button btn_register ,btn_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.petinsert);

        et_name = findViewById(R.id.et_name);
        et_age = findViewById(R.id.et_age);
        et_type = findViewById(R.id.et_type);
        radioGroup = findViewById(R.id.radioGroup);
        radioMale = findViewById(R.id.radioMale);
        radioFemale = findViewById(R.id.radioFemale);
        btn_register = findViewById(R.id.btn_register);
        btn_back = findViewById(R.id.btn_back);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PetInsertActivity.this, HomeActivity.class);
                startActivity(intent);
            }
        });

        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = et_name.getText().toString();
                String age = et_age.getText().toString();
                String type = et_type.getText().toString();

                int selectedId = radioGroup.getCheckedRadioButtonId();
                String gender = "";
                if (selectedId == radioMale.getId()) {
                    gender = "수컷";
                } else if (selectedId == radioFemale.getId()) {
                    gender = "암컷";
                }

                // 반려동물 정보를 HomeActivity로 전달
                Intent intent = new Intent();
                intent.putExtra("name", name);
                intent.putExtra("age", age);
                intent.putExtra("type", type);
                intent.putExtra("gender", gender);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }
}
